#!/bin/bash

# Angular Application Deployment Script
# Usage: ./deploy.sh [environment] [version]

set -e  # Exit on any error

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
ENVIRONMENT=${1:-staging}
VERSION=${2:-latest}
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Load environment-specific configuration
load_config() {
    local config_file="$SCRIPT_DIR/config/${ENVIRONMENT}.env"
    
    if [[ -f "$config_file" ]]; then
        log "Loading configuration for $ENVIRONMENT environment"
        source "$config_file"
    else
        error "Configuration file not found: $config_file"
        exit 1
    fi
}

# Health check function
health_check() {
    local url=$1
    local max_attempts=30
    local attempt=1
    
    log "Performing health check on $url"
    
    while [[ $attempt -le $max_attempts ]]; do
        if curl -f -s "$url/health" > /dev/null; then
            success "Health check passed"
            return 0
        fi
        
        log "Health check attempt $attempt/$max_attempts failed, retrying in 10s..."
        sleep 10
        ((attempt++))
    done
    
    error "Health check failed after $max_attempts attempts"
    return 1
}

# Backup current deployment
backup_deployment() {
    if [[ "$ENVIRONMENT" == "production" ]]; then
        log "Creating backup of current deployment"
        
        local backup_dir="/backups/deployments/${TIMESTAMP}"
        mkdir -p "$backup_dir"
        
        # Backup database
        if [[ -n "$DATABASE_URL" ]]; then
            log "Backing up database"
            pg_dump "$DATABASE_URL" > "$backup_dir/database_backup.sql"
        fi
        
        # Backup application files if they exist
        if [[ -d "/var/www/html" ]]; then
            log "Backing up application files"
            tar -czf "$backup_dir/app_backup.tar.gz" -C "/var/www" html/
        fi
        
        success "Backup created at $backup_dir"
    fi
}

# Deploy using Docker Compose
deploy_docker_compose() {
    log "Deploying using Docker Compose"
    
    cd "$PROJECT_ROOT"
    
    # Set environment variables
    export BUILD_NUMBER=$VERSION
    export DOCKER_REGISTRY=${DOCKER_REGISTRY:-"your-registry.com"}
    
    # Pull latest images
    log "Pulling latest Docker images"
    docker-compose -f docker-compose.${ENVIRONMENT}.yml pull
    
    # Stop existing services
    log "Stopping existing services"
    docker-compose -f docker-compose.${ENVIRONMENT}.yml down
    
    # Start new services
    log "Starting new services"
    docker-compose -f docker-compose.${ENVIRONMENT}.yml up -d
    
    # Wait for services to be ready
    sleep 30
    
    success "Docker Compose deployment completed"
}

# Deploy to Kubernetes
deploy_kubernetes() {
    log "Deploying to Kubernetes"
    
    # Update deployment image
    kubectl set image deployment/angular-app angular-app="$DOCKER_REGISTRY/angular-app:$VERSION" -n "$NAMESPACE"
    kubectl set image deployment/backend-api backend-api="$DOCKER_REGISTRY/backend-api:$VERSION" -n "$NAMESPACE"
    
    # Wait for rollout to complete
    log "Waiting for deployment rollout"
    kubectl rollout status deployment/angular-app -n "$NAMESPACE" --timeout=300s
    kubectl rollout status deployment/backend-api -n "$NAMESPACE" --timeout=300s
    
    success "Kubernetes deployment completed"
}

# Deploy static files to S3/CDN
deploy_static_files() {
    log "Deploying static files"
    
    local dist_dir="$PROJECT_ROOT/dist/angular-ci-cd-app"
    
    if [[ ! -d "$dist_dir" ]]; then
        error "Build directory not found: $dist_dir"
        return 1
    fi
    
    # Deploy to S3
    if [[ -n "$S3_BUCKET" ]]; then
        log "Deploying to S3 bucket: $S3_BUCKET"
        aws s3 sync "$dist_dir" "s3://$S3_BUCKET" --delete --cache-control "max-age=31536000"
        
        # Invalidate CloudFront cache
        if [[ -n "$CLOUDFRONT_DISTRIBUTION_ID" ]]; then
            log "Invalidating CloudFront cache"
            aws cloudfront create-invalidation --distribution-id "$CLOUDFRONT_DISTRIBUTION_ID" --paths "/*"
        fi
    fi
    
    # Deploy via rsync
    if [[ -n "$DEPLOY_HOST" ]]; then
        log "Deploying via rsync to $DEPLOY_HOST"
        rsync -avz --delete "$dist_dir/" "$DEPLOY_USER@$DEPLOY_HOST:$DEPLOY_PATH"
    fi
    
    success "Static files deployment completed"
}

# Run database migrations
run_migrations() {
    if [[ -n "$RUN_MIGRATIONS" && "$RUN_MIGRATIONS" == "true" ]]; then
        log "Running database migrations"
        
        # Run migrations in backend container
        if [[ "$DEPLOYMENT_TYPE" == "docker" ]]; then
            docker-compose -f docker-compose.${ENVIRONMENT}.yml exec -T backend-api npm run migrate
        elif [[ "$DEPLOYMENT_TYPE" == "kubernetes" ]]; then
            kubectl exec deployment/backend-api -n "$NAMESPACE" -- npm run migrate
        fi
        
        success "Database migrations completed"
    fi
}

# Smoke tests
run_smoke_tests() {
    log "Running smoke tests"
    
    local base_url=${BASE_URL:-"http://localhost"}
    
    # Test application endpoints
    local endpoints=(
        "$base_url/health"
        "$base_url/api/health"
        "$base_url/"
    )
    
    for endpoint in "${endpoints[@]}"; do
        log "Testing endpoint: $endpoint"
        if curl -f -s "$endpoint" > /dev/null; then
            success "✓ $endpoint"
        else
            error "✗ $endpoint"
            return 1
        fi
    done
    
    success "All smoke tests passed"
}

# Rollback function
rollback() {
    error "Deployment failed, initiating rollback"
    
    if [[ "$DEPLOYMENT_TYPE" == "docker" ]]; then
        log "Rolling back Docker Compose deployment"
        # Rollback to previous version
        export BUILD_NUMBER=${PREVIOUS_VERSION:-"latest"}
        docker-compose -f docker-compose.${ENVIRONMENT}.yml up -d
    elif [[ "$DEPLOYMENT_TYPE" == "kubernetes" ]]; then
        log "Rolling back Kubernetes deployment"
        kubectl rollout undo deployment/angular-app -n "$NAMESPACE"
        kubectl rollout undo deployment/backend-api -n "$NAMESPACE"
    fi
    
    warning "Rollback completed"
}

# Notification function
send_notification() {
    local status=$1
    local message=$2
    
    # Slack notification
    if [[ -n "$SLACK_WEBHOOK" ]]; then
        local color="good"
        local icon="✅"
        
        if [[ "$status" == "failure" ]]; then
            color="danger"
            icon="❌"
        elif [[ "$status" == "warning" ]]; then
            color="warning"
            icon="⚠️"
        fi
        
        curl -X POST -H 'Content-type: application/json' \
            --data "{\"text\":\"$icon Deployment $status: $message\"}" \
            "$SLACK_WEBHOOK"
    fi
    
    # Email notification
    if [[ -n "$EMAIL_RECIPIENTS" ]]; then
        echo "$message" | mail -s "Deployment $status - $ENVIRONMENT" "$EMAIL_RECIPIENTS"
    fi
}

# Main deployment function
main() {
    log "Starting deployment to $ENVIRONMENT environment (version: $VERSION)"
    
    # Load configuration
    load_config
    
    # Validate required variables
    if [[ -z "$DEPLOYMENT_TYPE" ]]; then
        error "DEPLOYMENT_TYPE not set in configuration"
        exit 1
    fi
    
    # Create backup for production
    if [[ "$ENVIRONMENT" == "production" ]]; then
        backup_deployment
    fi
    
    # Deploy based on type
    case "$DEPLOYMENT_TYPE" in
        "docker")
            deploy_docker_compose
            ;;
        "kubernetes")
            deploy_kubernetes
            ;;
        "static")
            deploy_static_files
            ;;
        *)
            error "Unknown deployment type: $DEPLOYMENT_TYPE"
            exit 1
            ;;
    esac
    
    # Run migrations if needed
    run_migrations
    
    # Health check
    if [[ -n "$BASE_URL" ]]; then
        if ! health_check "$BASE_URL"; then
            rollback
            send_notification "failure" "Deployment failed health check"
            exit 1
        fi
    fi
    
    # Run smoke tests
    if ! run_smoke_tests; then
        rollback
        send_notification "failure" "Deployment failed smoke tests"
        exit 1
    fi
    
    success "Deployment to $ENVIRONMENT completed successfully!"
    send_notification "success" "Deployment to $ENVIRONMENT completed successfully (version: $VERSION)"
}

# Script execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    # Check if help is requested
    if [[ "$1" == "-h" || "$1" == "--help" ]]; then
        echo "Usage: $0 [environment] [version]"
        echo ""
        echo "Arguments:"
        echo "  environment    Target environment (staging, production) [default: staging]"
        echo "  version        Version/tag to deploy [default: latest]"
        echo ""
        echo "Examples:"
        echo "  $0 staging v1.2.3"
        echo "  $0 production latest"
        exit 0
    fi
    
    # Trap errors and run rollback
    trap 'rollback' ERR
    
    # Run main function
    main "$@"
fi