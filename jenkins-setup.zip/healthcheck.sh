#!/bin/sh

# Health check script for Angular application

# Check if Nginx is running
if ! pgrep nginx > /dev/null; then
    echo "Nginx is not running"
    exit 1
fi

# Check if the application responds
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost/health)

if [ "$HTTP_CODE" = "200" ]; then
    echo "Health check passed"
    exit 0
else
    echo "Health check failed with HTTP code: $HTTP_CODE"
    exit 1
fi