# Angular CI/CD Pipeline with Jenkins

A comprehensive CI/CD pipeline setup for Angular applications using Jenkins, Docker, and Kubernetes with automated testing, deployment, and monitoring.

## 🏗️ Architecture Overview

This pipeline provides:
- **Automated Testing**: Unit tests, E2E tests, linting, and security audits
- **Multi-Environment Deployment**: Staging and production environments
- **Container Orchestration**: Docker and Kubernetes support
- **Monitoring & Alerting**: Prometheus, Grafana, and health checks
- **Security**: Vulnerability scanning and secure deployments
- **Rollback Capabilities**: Automated rollback on deployment failures

## 📁 Project Structure

```
├── Jenkinsfile                 # Main Jenkins pipeline configuration
├── package.json               # Node.js dependencies and scripts
├── angular.json               # Angular CLI configuration
├── Dockerfile                 # Docker image definition
├── docker-compose.yml         # Local development environment
├── docker-compose.prod.yml    # Production Docker Compose
├── nginx.conf                 # Nginx configuration
├── healthcheck.sh             # Health check script
├── karma.conf.js              # Karma test configuration
├── .eslintrc.json            # ESLint configuration
├── .prettierrc               # Prettier configuration
├── jenkins-setup.md          # Jenkins setup guide
├── deployment-scripts/        # Deployment automation
│   ├── deploy.sh             # Main deployment script
│   └── config/               # Environment configurations
│       ├── staging.env       # Staging environment variables
│       └── production.env    # Production environment variables
└── k8s/                      # Kubernetes manifests
    ├── namespace.yaml        # Kubernetes namespaces
    ├── deployment.yaml       # Application deployments
    ├── service.yaml          # Kubernetes services
    ├── ingress.yaml          # Ingress configuration
    ├── secrets.yaml          # Secret management
    └── hpa.yaml              # Horizontal Pod Autoscaler
```

## 🚀 Quick Start

### Prerequisites

1. **Jenkins Server** with required plugins:
   - Pipeline
   - NodeJS
   - Docker Pipeline
   - Git
   - HTML Publisher
   - JUnit

2. **Docker** installed on Jenkins server

3. **Kubernetes cluster** (for production deployment)

4. **Git repository** with webhook access

### Setup Steps

1. **Clone Repository**
   ```bash
   git clone <your-repository-url>
   cd angular-ci-cd-pipeline
   ```

2. **Configure Jenkins**
   - Follow the detailed guide in [`jenkins-setup.md`](computer:///home/user/jenkins-setup.md)
   - Configure Node.js tools
   - Set up credentials
   - Create pipeline job

3. **Environment Configuration**
   - Update environment files in [`deployment-scripts/config/`](computer:///home/user/deployment-scripts/config/)
   - Configure your domain names, database URLs, and API keys
   - Set up notification webhooks

4. **Deploy Infrastructure**
   ```bash
   # For Docker Compose
   docker-compose up -d
   
   # For Kubernetes
   kubectl apply -f k8s/
   ```

## 📋 Pipeline Stages

### 1. Code Quality & Testing
- **Checkout**: Pull latest code from repository
- **Install Dependencies**: Install npm packages
- **Linting**: ESLint code quality checks
- **Prettier**: Code formatting validation
- **Security Audit**: npm audit for vulnerabilities
- **Unit Tests**: Karma/Jasmine tests with coverage
- **E2E Tests**: Protractor end-to-end testing

### 2. Build & Analysis
- **Build**: Angular production build with optimization
- **Bundle Analysis**: Webpack bundle size analysis
- **Docker Build**: Create container images
- **Artifact Archiving**: Store build artifacts

### 3. Deployment
- **Staging Deployment**: Automatic deployment to staging
- **Production Approval**: Manual approval gate for production
- **Production Deployment**: Deploy to production environment
- **Health Checks**: Verify deployment health
- **Smoke Tests**: Basic functionality verification

### 4. Post-Deployment
- **Monitoring Setup**: Configure monitoring dashboards
- **Notification**: Send deployment status notifications
- **Cleanup**: Clean up resources and artifacts

## 🔧 Configuration

### Environment Variables

Configure the following variables in Jenkins or environment files:

```bash
# Docker Registry
DOCKER_REGISTRY=your-registry.com

# Database
DATABASE_URL=postgresql://user:password@host:5432/database

# API Keys
API_KEY=your-api-key
JWT_SECRET=your-jwt-secret

# Notifications
SLACK_WEBHOOK=your-slack-webhook
EMAIL_RECIPIENTS=team@company.com

# Deployment
BASE_URL=https://your-app.com
S3_BUCKET=your-s3-bucket
```

### Branch Strategy

- **Feature Branches**: Basic build and test only
- **Develop Branch**: Full pipeline with staging deployment
- **Main/Master Branch**: Full pipeline with production deployment

## 📊 Monitoring & Alerting

### Built-in Monitoring
- **Prometheus**: Metrics collection
- **Grafana**: Visualization dashboards
- **Health Checks**: Application health monitoring
- **Alerts**: Automatic failure notifications

### Key Metrics
- Application response time
- Error rates
- Resource utilization
- Deployment frequency
- Build success rates

## 🔒 Security Features

### Code Security
- Automated dependency vulnerability scanning
- ESLint security rules
- Security headers in Nginx configuration
- Container security scanning

### Deployment Security
- Secure credential management with Jenkins credentials
- HTTPS enforcement
- Kubernetes RBAC
- Network policies

## 🔄 Deployment Strategies

### 1. Docker Compose (Development/Staging)
```bash
# Deploy to staging
./deployment-scripts/deploy.sh staging v1.2.3

# Deploy to production
./deployment-scripts/deploy.sh production v1.2.3
```

### 2. Kubernetes (Production)
- Rolling updates with zero downtime
- Horizontal Pod Autoscaling
- Health checks and readiness probes
- Automatic rollback on failures

### 3. Static File Deployment (CDN)
- AWS S3 + CloudFront
- Automated cache invalidation
- Optimized asset delivery

## 🚨 Troubleshooting

### Common Issues

1. **Build Failures**
   - Check Node.js version compatibility
   - Verify dependencies in package.json
   - Review build logs for specific errors

2. **Test Failures**
   - Ensure Chrome/Chromium is available for testing
   - Check test configuration in karma.conf.js
   - Verify test environment setup

3. **Deployment Issues**
   - Verify environment configurations
   - Check network connectivity
   - Review deployment logs

4. **Health Check Failures**
   - Verify application is responding on correct port
   - Check health endpoint implementation
   - Review container logs

### Debug Commands

```bash
# Check build artifacts
ls -la dist/

# Test Docker container locally
docker run -p 8080:80 your-app:latest

# Check Kubernetes deployment
kubectl get pods -n angular-app-production
kubectl logs deployment/angular-app -n angular-app-production

# Verify health endpoints
curl http://your-app.com/health
```

## 📈 Performance Optimization

### Build Optimization
- AOT compilation enabled
- Tree shaking and dead code elimination
- Bundle optimization and splitting
- Lazy loading implementation

### Pipeline Optimization
- Parallel execution where possible
- Docker layer caching
- Selective stage execution based on branch
- Artifact caching

### Runtime Optimization
- Nginx gzip compression
- Static asset caching
- CDN integration
- Database connection pooling

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📞 Support

For questions and support:
- Create an issue in the repository
- Contact the development team
- Check the troubleshooting guide

## 🔗 Links

- [Jenkins Setup Guide](computer:///home/user/jenkins-setup.md)
- [Docker Configuration](computer:///home/user/Dockerfile)
- [Kubernetes Manifests](computer:///home/user/k8s/)
- [Deployment Scripts](computer:///home/user/deployment-scripts/)

---

**Note**: Remember to replace placeholder values (like `your-registry.com`, `your-app.com`) with your actual configuration values before deploying.