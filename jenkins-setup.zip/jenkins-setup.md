# Jenkins Setup Guide for Angular Application Pipeline

## Prerequisites

### 1. Jenkins Installation
- Jenkins server with Docker support
- Node.js plugin installed
- Docker plugin installed
- Required plugins:
  - Pipeline
  - Git
  - NodeJS
  - Docker Pipeline
  - HTML Publisher
  - JUnit
  - Slack Notification (optional)
  - Email Extension (optional)

### 2. System Requirements
- Jenkins server with minimum 4GB RAM
- Docker installed on Jenkins server
- Git access to your repository
- Network access to deployment targets

## Jenkins Configuration

### 1. Global Tool Configuration

Navigate to **Manage Jenkins > Global Tool Configuration**

#### Node.js Installation
- Add NodeJS installation
- Name: `NodeJS-18`
- Version: `NodeJS 18.x.x`
- Global npm packages: `@angular/cli@16.0.0`

#### Git Configuration
- Configure Git installation path
- Set up Git credentials for repository access

### 2. Pipeline Job Setup

1. **Create New Pipeline Job**
   - Click "New Item"
   - Enter job name: `angular-ci-cd-pipeline`
   - Select "Pipeline"
   - Click "OK"

2. **Configure Pipeline**
   - **General Tab:**
     - Add description
     - Enable "GitHub project" if using GitHub
     - Set project URL

   - **Build Triggers:**
     - Enable "GitHub hook trigger for GITScm polling"
     - Or configure polling: `H/5 * * * *` (every 5 minutes)

   - **Pipeline Tab:**
     - Definition: "Pipeline script from SCM"
     - SCM: Git
     - Repository URL: Your Git repository URL
     - Credentials: Add your Git credentials
     - Branch: `*/main` (or your default branch)
     - Script Path: `Jenkinsfile`

### 3. Environment Variables

Configure the following environment variables in Jenkins:

```bash
# Docker Registry (optional)
DOCKER_REGISTRY=your-registry.com

# Notification Settings (optional)
SLACK_WEBHOOK=your-slack-webhook-url
EMAIL_RECIPIENTS=team@company.com

# Deployment Settings
STAGING_URL=https://staging.your-app.com
PRODUCTION_URL=https://your-app.com
```

### 4. Credentials Setup

Add the following credentials in **Manage Jenkins > Manage Credentials**:

- **Git Repository Access:**
  - Type: Username with password or SSH Username with private key
  - ID: `git-credentials`

- **Docker Registry (if using):**
  - Type: Username with password
  - ID: `docker-registry-credentials`

- **Deployment Credentials:**
  - Type: SSH Username with private key or Secret text
  - ID: `deployment-credentials`

## Pipeline Features

### 1. Build Stages
- **Checkout:** Pull source code from repository
- **Install Dependencies:** Install npm packages
- **Code Quality:** ESLint, Prettier, Security audit
- **Unit Tests:** Karma/Jasmine tests with coverage
- **Build:** Angular production build
- **Bundle Analysis:** Webpack bundle analyzer
- **E2E Tests:** End-to-end testing
- **Docker Build:** Create Docker image
- **Deploy:** Deploy to staging/production
- **Health Check:** Verify deployment

### 2. Branch-based Workflows

- **Feature Branches:** Basic build and test only
- **Develop Branch:** Full pipeline with staging deployment
- **Main/Master Branch:** Full pipeline with production deployment (requires approval)

### 3. Reporting and Notifications

- **Test Results:** JUnit test reporting
- **Code Coverage:** HTML coverage reports
- **Lint Results:** ESLint HTML reports
- **Bundle Analysis:** Webpack bundle size analysis
- **Slack/Email:** Build status notifications

## Environment-Specific Configurations

### Development Environment
```javascript
// src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000/api',
  enableDebug: true
};
```

### Staging Environment
```javascript
// src/environments/environment.staging.ts
export const environment = {
  production: false,
  apiUrl: 'https://staging-api.your-app.com/api',
  enableDebug: true
};
```

### Production Environment
```javascript
// src/environments/environment.prod.ts
export const environment = {
  production: true,
  apiUrl: 'https://api.your-app.com/api',
  enableDebug: false
};
```

## Deployment Strategies

### 1. Static File Deployment
```bash
# Example: Deploy to AWS S3
aws s3 sync dist/ s3://your-bucket-name --delete

# Example: Deploy to server via rsync
rsync -avz --delete dist/ user@server:/var/www/html/
```

### 2. Docker Deployment
```bash
# Build and push Docker image
docker build -t your-app:${BUILD_NUMBER} .
docker push your-registry/your-app:${BUILD_NUMBER}

# Deploy with Docker Compose
docker-compose -f docker-compose.prod.yml up -d
```

### 3. Kubernetes Deployment
```yaml
# k8s-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: angular-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: angular-app
  template:
    metadata:
      labels:
        app: angular-app
    spec:
      containers:
      - name: angular-app
        image: your-registry/angular-app:latest
        ports:
        - containerPort: 80
```

## Security Best Practices

### 1. Dependency Security
- Regular `npm audit` checks
- Automated dependency updates
- Vulnerability scanning in CI/CD

### 2. Container Security
- Use official base images
- Regular image updates
- Security scanning
- Non-root user in containers

### 3. Deployment Security
- Secure credential management
- HTTPS enforcement
- Security headers in Nginx
- Regular security updates

## Monitoring and Logging

### 1. Application Monitoring
- Health check endpoints
- Performance monitoring
- Error tracking
- User analytics

### 2. Infrastructure Monitoring
- Server resource monitoring
- Container metrics
- Network monitoring
- Log aggregation

### 3. Pipeline Monitoring
- Build success/failure rates
- Build duration trends
- Test coverage trends
- Deployment frequency

## Troubleshooting

### Common Issues

1. **Node.js Version Mismatch**
   - Ensure Jenkins uses correct Node.js version
   - Check `node --version` in build logs

2. **Chrome/Chromium Issues**
   - Install Chrome in Jenkins environment
   - Use ChromeHeadless for testing
   - Configure proper flags for containerized environments

3. **Memory Issues**
   - Increase Jenkins heap size
   - Configure Node.js memory limits
   - Use `--max-old-space-size` flag

4. **Permission Issues**
   - Check file permissions
   - Configure proper user permissions
   - Docker socket permissions

### Debug Commands
```bash
# Check Node.js and npm versions
node --version
npm --version

# Check available browsers for testing
npx karma --browsers=?

# Check Docker status
docker ps
docker images

# Check build artifacts
ls -la dist/
```

## Performance Optimization

### 1. Build Optimization
- Enable AOT compilation
- Use build optimizer
- Configure bundle budgets
- Implement lazy loading

### 2. Pipeline Optimization
- Parallel execution where possible
- Cache node_modules
- Skip unnecessary stages for feature branches
- Use Docker layer caching

### 3. Deployment Optimization
- Blue-green deployments
- Rolling updates
- CDN integration
- Caching strategies

This setup provides a comprehensive CI/CD pipeline for Angular applications with Jenkins, ensuring code quality, automated testing, and reliable deployments.